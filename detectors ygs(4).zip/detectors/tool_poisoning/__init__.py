"""Tool poisoning detectors."""
