from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class TextChunk:
    location: str
    text: str
    field_type: str
    source: str = "raw"


STRUCTURAL_LOCATION_FRAGMENTS = (
    ".required[",
    ".enum[",
    ".examples[",
    ".const",
    ".default",
)

EVALUATION_LOCATION_SUFFIXES = (
    "_meta.expected_signal",
    "meta.expected_signal",
    "_meta.real_world_reference",
    "meta.real_world_reference",
    "_meta.difficulty",
    "meta.difficulty",
    "_meta.scenario_id",
    "meta.scenario_id",
)


def iter_text_values(value: Any, prefix: str) -> list[tuple[str, str]]:
    values: list[tuple[str, str]] = []

    if isinstance(value, str):
        values.append((prefix, value))
    elif isinstance(value, dict):
        for key, nested_value in value.items():
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            values.extend(iter_text_values(nested_value, child_prefix))
    elif isinstance(value, list):
        for index, nested_value in enumerate(value):
            child_prefix = f"{prefix}[{index}]"
            values.extend(iter_text_values(nested_value, child_prefix))

    return values


def collect_text_chunks(
    tool: Any,
    *,
    include_structural_values: bool = True,
    include_title: bool = True,
) -> list[TextChunk]:
    chunks: list[TextChunk] = []

    if include_title:
        title = _get_field(tool, "title")
        if isinstance(title, str) and title.strip():
            chunks.append(
                TextChunk(
                    location="title",
                    text=title.strip(),
                    field_type="title",
                )
            )

    description = _get_field(tool, "description")
    if isinstance(description, str) and description.strip():
        chunks.append(
            TextChunk(
                location="description",
                text=description.strip(),
                field_type="description",
            )
        )

    for field_name in ("input_schema", "output_schema", "annotations", "meta"):
        value = _get_field(tool, field_name)
        if value is None:
            continue
        for location, text in iter_text_values(value, field_name):
            if is_evaluation_location(location):
                continue
            if not include_structural_values and is_structural_location(location):
                continue
            stripped_text = text.strip()
            if not stripped_text:
                continue
            chunks.append(
                TextChunk(
                    location=location,
                    text=stripped_text,
                    field_type=field_name,
                )
            )

    return chunks


def is_structural_location(location: str) -> bool:
    return any(fragment in location for fragment in STRUCTURAL_LOCATION_FRAGMENTS)


def is_evaluation_location(location: str) -> bool:
    return any(
        location.endswith(part) or location == part
        for part in EVALUATION_LOCATION_SUFFIXES
    )


def _get_field(tool: Any, field_name: str) -> Any:
    if isinstance(tool, dict):
        if field_name == "meta":
            return tool.get("meta") or tool.get("_meta")
        if field_name == "input_schema":
            return tool.get("input_schema") or tool.get("inputSchema")
        if field_name == "output_schema":
            return tool.get("output_schema") or tool.get("outputSchema")
        return tool.get(field_name)
    return getattr(tool, field_name, None)
